🎧 LATEST BOUNCE EXTRACTOR

How to Use:
1. Unzip this folder
2. Double-click `run.command`
3. Use arrow keys to select your Pro Tools drive
4. Script will auto-install dependencies if needed
5. Latest bounced WAV files will be copied to your Desktop in "Collected Bounces"

🛠 Dependencies: Python 3, pip, internet connection (for first run only)

⚠️ Gatekeeper Warning
	If users double-click and see “unidentified developer” warning:
		Right-click → Open
		Approve via System Preferences > Security > Open Anyway


Ignore this Error (if it prints):

  WARNING: The script tqdm is installed in '/Users/jshriver/.local/bin' which is not on PATH.
  Consider adding this directory to PATH or, if you prefer to suppress this warning, use --no-warn-script-location.