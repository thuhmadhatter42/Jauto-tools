🎧 AAX PLUGIN LISTER

How to Use:
1. Unzip this folder
2. Double-click `run.command`
3. Follow the prompts to enter the path to your AAX plugins folder and the desired location for the CSV export.

⚠️ Gatekeeper Warning
	If users double-click and see “unidentified developer” warning:
		Right-click → Open
		Approve via System Preferences > Security > Open Anyway