from _collections_abc import *
from _collections_abc import __all__
from _collections_abc import _CallableGenericAlias
